package pt.tooyummytogo.exceptions;
/*
 * Esta classe representa a excepcao comerciantes nao encontrados
 */
public class ComerciantesNotFoundException extends Exception {

}
