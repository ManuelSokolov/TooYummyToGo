package pt.tooyummytogo.exceptions;
/*
 * Esta classe representa a excepcao para uma reserva falhada
 */
public class ReservaFalhadaException extends Exception {

}
