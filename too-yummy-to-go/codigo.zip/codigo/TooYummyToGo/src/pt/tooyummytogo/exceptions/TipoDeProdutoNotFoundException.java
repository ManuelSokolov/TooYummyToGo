package pt.tooyummytogo.exceptions;
/*
 * Esta classe representa a excepcao para o tipo de produto nao encontrado
 */
public class TipoDeProdutoNotFoundException extends Exception {

}
