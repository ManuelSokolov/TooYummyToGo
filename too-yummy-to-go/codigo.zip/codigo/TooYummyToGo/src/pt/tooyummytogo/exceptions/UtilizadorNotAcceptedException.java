package pt.tooyummytogo.exceptions;

public class UtilizadorNotAcceptedException extends Exception {

}
